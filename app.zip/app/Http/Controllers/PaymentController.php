<?php

namespace App\Http\Controllers;

use App\Http\Requests\CouponValidationRequest;
use App\Http\Requests\CreatePaymentOrderRequest;
use App\Models\Book;
use App\Models\BookPurchase;
use App\Models\CouponUsage;
use App\Models\PaymentOrder;
use App\Models\Subscription;
use App\Models\User;
use App\Services\CouponService;
use App\Services\InfinitoSmsService;
use App\Services\MagazinePlanCatalog;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Razorpay\Api\Api;

class PaymentController extends Controller
{
    public function createOrder(CreatePaymentOrderRequest $request, CouponService $couponService, MagazinePlanCatalog $planCatalog): JsonResponse
    {
        $data = $request->validated();
        $userId = $this->userId($request);
        if (isset($data['userId']) && (int) $data['userId'] !== $userId) return response()->json(['message' => 'You can only create an order for yourself'], 403);
        $book = null;
        if (isset($data['book_id'])) {
            $book = Book::where('is_published', true)->find($data['book_id']);
            if (!$book) return response()->json(['message' => 'Book not found'], 404);
            if (!$book->price_minor || $book->price_minor < 100) return response()->json(['message' => 'Book is not available for purchase'], 422);
            if (BookPurchase::where('user_id', $userId)->where('book_id', $book->id)->exists()) {
                return response()->json(['message' => 'You already own this book'], 409);
            }
            $planType = 'book_'.$book->id;
            $plan = ['name' => $book->title];
            $originalAmountPaise = $book->price_minor;
        } else {
            $planType = $planCatalog->normalizeKey($data['plan']);
            $plan = $planCatalog->get($planType);
            if (!$plan) return response()->json(['message' => 'Unsupported plan'], 422);
            $originalAmountPaise = $planCatalog->amountFor($plan);
            if ($originalAmountPaise === null) {
                return response()->json(['message' => 'Test pricing requires Razorpay test credentials and an amount of at least ₹1'], 503);
            }
        }
        $amountPaise = $originalAmountPaise;
        $coupon = null;
        $discountPaise = 0;
        if (!empty($data['coupon_code'])) {
            $quote = $couponService->quote($data['coupon_code'], $userId, $amountPaise, $planType);
            if (!$quote['valid']) return response()->json(['valid' => false, 'message' => $quote['message']], $quote['status']);
            $coupon = $quote['coupon'];
            $originalAmountPaise = $quote['original_amount'];
            $discountPaise = $quote['discount_amount'];
            $amountPaise = $quote['final_amount'];
        }
        $keyId = (string) config('services.razorpay.key_id');
        $keySecret = (string) config('services.razorpay.key_secret');
        if ($keyId === '' || $keySecret === '') return response()->json(['message' => 'Payment gateway is not configured'], 500);
        $receipt = 'eru_'.bin2hex(random_bytes(12));
        try {
            $notes = ['userId' => (string) $userId, 'type' => $book ? 'book' : 'subscription'];
            $notes[$book ? 'book_id' : 'plan'] = (string) ($book?->id ?? $planType);
            $gateway = (new Api($keyId, $keySecret))->order->create(['amount' => $amountPaise, 'currency' => 'INR', 'receipt' => $receipt, 'notes' => $notes]);
        } catch (\Throwable $exception) {
            Log::error('Razorpay order creation failed', [
                'exception' => get_class($exception),
                'message' => $exception->getMessage(),
                'user_id' => $userId,
                'plan' => $planType,
                'amount_paise' => $amountPaise,
                'coupon_code' => $data['coupon_code'] ?? null,
            ]);
            return response()->json(['message' => 'Payment gateway request failed'], 502);
        }
        PaymentOrder::create(['user_id' => $userId, 'razorpay_order_id' => $gateway['id'], 'amount' => $amountPaise, 'currency' => 'INR', 'receipt' => $receipt, 'plan_type' => $book ? null : $planType, 'book_id' => $book?->id, 'shipping_address' => $data['shipping_address'] ?? null, 'status' => 'created', 'coupon_id' => $coupon?->id, 'discount_amount' => $discountPaise]);
        return response()->json([
            'message' => 'Payment order created',
            'order_id' => $gateway['id'],
            'payment_key' => $keyId,
            'original_amount' => round($originalAmountPaise / 100, 2),
            'discount' => round($discountPaise / 100, 2),
            'final_amount' => round($amountPaise / 100, 2),
            'currency' => 'INR',
            'item_type' => $book ? 'book' : 'subscription',
            'book_id' => $book?->id,
            'book_title' => $book?->title,
            'order' => ['id' => $gateway['id'], 'amount' => $amountPaise, 'currency' => 'INR', 'receipt' => $receipt, 'key_id' => $keyId],
        ], 201);
    }

    public function validateCoupon(CouponValidationRequest $request, CouponService $couponService, MagazinePlanCatalog $planCatalog): JsonResponse
    {
        $data = $request->validated();
        if (isset($data['book_id'])) {
            $book = Book::where('is_published', true)->find($data['book_id']);
            if (!$book) return response()->json(['valid' => false, 'message' => 'Book not found'], 404);
            if (!$book->price_minor || $book->price_minor < 100) return response()->json(['valid' => false, 'message' => 'Book is not available for purchase'], 422);
            $planKey = 'book_'.$book->id;
            $amountPaise = $book->price_minor;
        } else {
            $plan = $planCatalog->get($data['plan']);
            if (!$plan) return response()->json(['valid' => false, 'message' => 'Unsupported plan'], 422);
            $planKey = $planCatalog->normalizeKey($data['plan']);
            $amountPaise = $planCatalog->amountFor($plan);
            if ($amountPaise === null) {
                return response()->json(['valid' => false, 'message' => 'Test pricing requires Razorpay test credentials and an amount of at least ₹1'], 503);
            }
        }

        $quote = $couponService->quote($data['coupon_code'], $this->userId($request), $amountPaise, $planKey);
        if (!$quote['valid']) return response()->json(['valid' => false, 'message' => $quote['message']], $quote['status']);

        return response()->json([
            'valid' => true,
            'original_amount' => round($quote['original_amount'] / 100, 2),
            'discount' => round($quote['discount_amount'] / 100, 2),
            'final_amount' => round($quote['final_amount'] / 100, 2),
            'currency' => 'INR',
        ]);
    }

    public function verifyPayment(Request $request): JsonResponse
    {
        $data = $request->validate([
            'order_id' => ['required_without:razorpay_order_id', 'string'],
            'payment_id' => ['required_without:razorpay_payment_id', 'string'],
            'signature' => ['required_without:razorpay_signature', 'string'],
            'razorpay_order_id' => ['required_without:order_id', 'string'],
            'razorpay_payment_id' => ['required_without:payment_id', 'string'],
            'razorpay_signature' => ['required_without:signature', 'string'],
        ]);
        $data['order_id'] ??= $data['razorpay_order_id'];
        $data['payment_id'] ??= $data['razorpay_payment_id'];
        $data['signature'] ??= $data['razorpay_signature'];
        $order = PaymentOrder::where('razorpay_order_id', $data['order_id'])->where('user_id', $this->userId($request))->first();
        if (!$order) return response()->json(['message' => 'Payment order not found'], 404);
        if ($order->currency !== 'INR' || $order->status === 'paid') return response()->json(['message' => 'Payment order cannot be verified'], 409);
        $book = $order->book_id ? Book::find($order->book_id) : null;
        if ($order->book_id && !$book) return response()->json(['message' => 'Payment order book no longer exists'], 409);
        $planCatalog = app(MagazinePlanCatalog::class);
        $planType = $book ? null : $planCatalog->normalizeKey($order->plan_type ?? '');
        $plan = $book ? null : $planCatalog->get($planType);
        if (!$book && !$plan) return response()->json(['message' => 'Payment order has an unsupported plan'], 409);
        try { (new Api((string) config('services.razorpay.key_id'), (string) config('services.razorpay.key_secret')))->utility->verifyPaymentSignature(['razorpay_order_id' => $data['order_id'], 'razorpay_payment_id' => $data['payment_id'], 'razorpay_signature' => $data['signature']]); }
        catch (\Throwable) { return response()->json(['success' => false, 'message' => 'Payment signature verification failed'], 400); }
        DB::transaction(function () use ($order, $data, $book, $plan, $planType, $planCatalog): void {
            $order->update(['razorpay_payment_id' => $data['payment_id'], 'signature' => $data['signature'], 'status' => 'paid']);
            if ($order->coupon_id) {
                CouponUsage::firstOrCreate(
                    ['coupon_id' => $order->coupon_id, 'user_id' => $order->user_id],
                    ['payment_order_id' => $order->id, 'discount_amount' => $order->discount_amount, 'used_at' => now()]
                );
            }
            if ($book) {
                BookPurchase::firstOrCreate(
                    ['user_id' => $order->user_id, 'book_id' => $book->id],
                    ['payment_order_id' => $order->id]
                );
                return;
            }

            $existingSubscriptions = Subscription::where('user_id', $order->user_id)
                ->where('status', 'active')
                ->get();
            foreach ($planCatalog->productsFor($planType) as $product) {
                $latestEntitlement = $existingSubscriptions
                    ->filter(fn (Subscription $subscription): bool => in_array($product, $planCatalog->productsFor($subscription->plan_type), true))
                    ->sortByDesc('end_date')
                    ->first();
                $start = $latestEntitlement && $latestEntitlement->end_date->isFuture()
                    ? $latestEntitlement->end_date->copy()
                    : Carbon::now();
                $end = isset($plan['months'])
                    ? $start->copy()->addMonths((int) $plan['months'])
                    : $start->copy()->addYears((int) ($plan['years'] ?? 1));
                Subscription::create([
                    'user_id' => $order->user_id,
                    'start_date' => $start,
                    'end_date' => $end,
                    'plan_type' => $planType,
                    'status' => 'active',
                ]);
            }
            User::whereKey($order->user_id)->update(['subscription_status' => 'active']);
        });
        $user = User::find($order->user_id);
        if ($user && $book === null) {
            try {
                app(InfinitoSmsService::class)->sendPaymentConfirmation($user->phone, $planType, $data['payment_id']);
            } catch (\Throwable $exception) {
                Log::warning('Payment confirmation SMS failed', [
                    'exception' => get_class($exception),
                    'message' => $exception->getMessage(),
                    'user_id' => $user->id,
                    'payment_id' => $data['payment_id'],
                ]);
            }
        }

        $paymentResponse = [
            'success' => true,
            'message' => 'Payment verified successfully',
            'payment_id' => $data['payment_id'],
            'order_id' => $data['order_id'],
        ];
        if ($book) {
            return response()->json(array_merge($paymentResponse, [
                'purchase_type' => 'book',
                'book_id' => $book->id,
                'book_url' => '/api/books/'.$book->id,
                'next_action' => 'open_book',
            ]));
        }

        return response()->json(array_merge($paymentResponse, $this->subscriptionResponse((int) $order->user_id)));
    }

    public function subscriptionStatus(int $userId, Request $request): JsonResponse
    {
        if ($userId !== $this->userId($request)) return response()->json(['message' => 'You can only view your own subscription'], 403);
        $response = $this->subscriptionResponse($userId);
        return response()->json($response);
    }

    private function subscriptionResponse(int $userId): array
    {
        $planCatalog = app(MagazinePlanCatalog::class);
        $subscriptions = Subscription::where('user_id', $userId)->get();
        $currentSubscription = $subscriptions->sortByDesc('end_date')->first();
        $activeSubscriptions = $subscriptions->filter(fn (Subscription $subscription): bool =>
            $subscription->status === 'active' && $subscription->end_date->isFuture()
        );
        $expirySubscription = $activeSubscriptions->sortBy('end_date')->first();
        $productAccess = [];
        foreach (['emagazine', 'print_magazine'] as $product) {
            $productAccess[$product] = $subscriptions->contains(fn (Subscription $subscription): bool =>
                $subscription->status === 'active'
                && $subscription->end_date->isFuture()
                && in_array($product, $planCatalog->productsFor($subscription->plan_type), true)
            );
        }
        $active = in_array(true, $productAccess, true);
        $expiryDate = $active ? $expirySubscription?->end_date : null;
        $daysRemaining = $expiryDate
            ? (int) Carbon::today()->diffInDays($expiryDate->copy()->startOfDay())
            : null;

        foreach ($subscriptions as $subscription) {
            if ($subscription->status === 'active' && !$subscription->end_date->isFuture()) {
                $subscription->update(['status' => 'expired']);
            }
        }

        User::whereKey($userId)->update(['subscription_status' => $active ? 'active' : 'expired']);

        $currentPlan = $currentSubscription ? $planCatalog->get($currentSubscription->plan_type) : null;
        $years = $currentPlan['years'] ?? null;

        return [
            'status' => $active ? 'active' : 'expired',
            'is_subscribed' => $active,
            'expiry_date' => $expiryDate?->toDateString(),
            'days_remaining' => $daysRemaining,
            'show_expiry_notification' => $active && $daysRemaining <= 60,
            'plan' => $currentSubscription?->plan_type,
            'start_date' => $currentSubscription?->start_date,
            'end_date' => $currentSubscription?->end_date,
            'subscription' => [
                'active' => $active,
                'plan_id' => $currentSubscription ? (string) ($years ?? $currentSubscription->plan_type) : null,
                'expiry_date' => $active ? $currentSubscription->end_date : null,
            ],
            'content_access' => [
                'emagazine' => ['visible' => true, 'accessible' => $productAccess['emagazine']],
                'print_magazine' => ['visible' => true, 'accessible' => $productAccess['print_magazine']],
                'subscription_plans' => ['visible' => !$active],
            ],
            'next_action' => $productAccess['emagazine'] ? 'open_emagazine_viewer' : 'show_magazine_options',
            'plans' => $this->availablePlans(),
        ];
    }

    private function availablePlans(): array
    {
        return app(MagazinePlanCatalog::class)->publicPlans();
    }

    private function userId(Request $request): int { return (int) $request->attributes->get('jwt_claims')['id']; }
}
